#include "include.h" 

char recdata[2];
u8 recstate=0;

void main(void)
{   
   
   DisableInterrupts;        //�ر����ж�
   PLL_Init(PLL200);         //��ʼ��PLLΪ200M������Ϊ40MHZ  
   LED_Init();
   UART_Init (UART_4,115200);//���ڳ�ʼ��
   
   LED_Ctrl(LEDALL,ON);
   time_delay_ms(100);       //��ʱ
   LED_Ctrl(LEDALL,OFF);
   
   UART_Irq_En(UART_4);
   EnableInterrupts;
   while(1)
   { 
     LED_Ctrl(LED0,ON);
     if(recstate==2)
      {
       if((recdata[0]=='1')&&(recdata[1]=='O'))
         {
           LED_Ctrl(LED1,ON);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='1'&&recdata[1]=='F')
         {
           LED_Ctrl(LED1,OFF);
           recstate=0;recdata[0]=0;
         } 
       else if(recdata[0]=='2'&&recdata[1]=='O')
         {
           LED_Ctrl(LED2,ON);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='2'&&recdata[1]=='F')
         {
           LED_Ctrl(LED2,OFF);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='3'&&recdata[1]=='O')
         {
           LED_Ctrl(LED3,ON);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='3'&&recdata[1]=='F')
         {
           LED_Ctrl(LED3,OFF);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='4'&&recdata[1]=='O')
         {
           LED_Ctrl(LED4,ON);
           recstate=0;recdata[0]=0;
         }
       else if(recdata[0]=='4'&&recdata[1]=='F')
         {
           LED_Ctrl(LED4,OFF);
           recstate=0;recdata[0]=0;
         }
       recstate=0;
      }
   }
}

void UART4_IRQHandler(void)
{
    recdata[recstate]=UART_Get_Char(UART_4);
    UART_Put_Char(UART_4,recdata[recstate]);
    recstate++;
}