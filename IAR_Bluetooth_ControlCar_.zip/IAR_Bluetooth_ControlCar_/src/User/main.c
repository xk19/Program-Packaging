#include "include.h" 

char recdata[2];
u8 recstate=0;
u16 pwm1=1000;
u16 pwm2=1000;
u16 pwm3=1000;
u16 pwm4=1000;
char str[6];
void Motor_Get(void);
void Send_Num(u16 temp);

void main(void)
{   
   
   DisableInterrupts;        //�ر����ж�
   PLL_Init(PLL200);         //��ʼ��PLLΪ200M������Ϊ40MHZ 
   
   LED_Init();
   UART_Init(UART_4,115200);//���ڳ�ʼ��
   
   FTM_PWM_Init(FTM0,FTM_CH0,50000,1000);
   FTM_PWM_Init(FTM0,FTM_CH1,50000,1000);
   //FTM_PWM_Init(FTM0,FTM_CH3,50000,1000);
   //FTM_PWM_Init(FTM0,FTM_CH4,50000,1000);
   
   LED_Ctrl(LED0,ON);
   time_delay_ms(100);       //��ʱ
   LED_Ctrl(LEDALL,ON);
   time_delay_ms(1000);       //��ʱ
   LED_Ctrl(LEDALL,OFF);
   
   UART_Irq_En(UART_4);
   EnableInterrupts;
   
   UART_Put_Char(UART_4,'6');
   UART_Put_Char(UART_4,'6');
   UART_Put_Char(UART_4,'6');
   Send_Num(pwm1);
   Send_Num(pwm2);
   while(1)
   {
     if(recstate==2)
     {
       if((recdata[0]=='F')&&(recdata[1]=='W'))
       {
         LED_Ctrl(LED0,ON);
         pwm1 += 1000;
         pwm2 += 1000;
         recstate=0;recdata[0]=0;
         time_delay_ms(100);
         LED_Ctrl(LED0,OFF);
       }
       else if(recdata[0]=='B'&&recdata[1]=='W')
       {
         LED_Ctrl(LED1,ON);
         pwm1 -= 1000;
         pwm2 -= 1000;
         recstate=0;recdata[0]=0;
         time_delay_ms(100);
         LED_Ctrl(LED1,OFF);
       } 
       else if(recdata[0]=='L'&&recdata[1]=='W')
       {
         LED_Ctrl(LED2,ON);
         pwm1 += 1000;
         pwm2 -= 1000;
         recstate=0;recdata[0]=0;
         time_delay_ms(100);
         LED_Ctrl(LED2,OFF);
       }
       else if(recdata[0]=='R'&&recdata[1]=='W')
       {
         LED_Ctrl(LED3,ON);
         pwm1 -= 1000;
         pwm2 += 1000;
         recstate=0;recdata[0]=0;
         time_delay_ms(100);
         LED_Ctrl(LED3,OFF);
       }
       else if(recdata[0]=='S'&&recdata[1]=='T')
       {
         LED_Ctrl(LED4,ON);
         pwm1 = 0;
         pwm2 = 0;
         recstate=0;recdata[0]=0;
         time_delay_ms(100);
         LED_Ctrl(LED4,OFF);
       }
       recstate=0;
       Send_Num(pwm1);
       Send_Num(pwm2);
     }
     Motor_Get();
   }
}

void UART4_IRQHandler(void)
{
    recdata[recstate]=UART_Get_Char(UART_4);
    UART_Put_Char(UART_4,recdata[recstate]);
    recstate++;
}

void Motor_Get(void)
{
  
  if(pwm1>=40000) pwm1=40000;
  if(pwm2>=40000) pwm2=40000;
  if(pwm1<=1000) pwm1=1000;
  if(pwm2<=1000) pwm2=1000;
  
  FTM_PWM_Duty(FTM0,FTM_CH0,pwm1);
  FTM_PWM_Duty(FTM0,FTM_CH1,pwm2);
  //FTM_PWM_Duty(FTM0,FTM_CH2,pwm3);
  //FTM_PWM_Duty(FTM0,FTM_CH3,pwm4); 
}

void Send_Num(u16 temp)
{
  u8 i=4;
  if(temp >= 10000)
  {
    while(temp)
    {
      str[i]=temp%10+0x30;
      i--;
      temp=temp/10;
    }
  }
  else if(temp < 9999)
  {
    i=3;
    while(temp)
    {
      str[i]=temp%10+0x30;
      i--;
      temp=temp/10;
    }
    str[4]=' '; 
  }
  str[5]=' ';
  UART_Put_Str(UART_4,str);
}
