#include <reg52.h>
#include <basic.h>


