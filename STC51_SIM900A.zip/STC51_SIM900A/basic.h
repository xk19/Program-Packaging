#ifndef _BASIC_H
#define _BASIC_H


#ifndef Rx_buffer_length
#define Rx_buffer_length    80
#endif

extern void Usart_PutChar(unsigned char cTxData);
extern void Delay_ms(unsigned int);
extern void Usart_PutString(unsigned char  *pcString);
extern void Clear_Rxbuffer(unsigned char length);
extern void Clear_CurrentBuffer(unsigned char Bit,unsigned char length);

extern unsigned char Rx_bit;
extern unsigned char Rx_counter;               	 //��־λ��λ������
extern unsigned char Rx_data[Rx_buffer_length];         //���ջ�������

#endif