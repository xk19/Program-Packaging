#include <basic_function.h>
#include <reg52.h>
void Delay_us(unsigned int t)
{ 
	while(t--);
}
void Delay_ms(unsigned int t)
{
	while(t--)
	{
		Delay_us(245);
		Delay_us(245);
	}
}

void Usart_Init(void)
{
	SCON  = 0x50;		        // SCON: ģʽ 1, 8-bit UART, ʹ�ܽ���  
    TMOD |= 0x20;               // TMOD: timer 1, mode 2, 8-bit ��װ
    TH1   = 0xFD;               // TH1:  ��װֵ 9600 ������ ���� 11.0592MHz  
    TR1   = 1;                  // TR1:  timer 1 ��                         
    EA    = 1;                  //�����ж�
    ES    = 1;     																
} 
	
void Usart_PutChar(unsigned char cTxData) 
{
	SBUF = cTxData;
	while(!TI);
		TI = 0;
}

//----------------------�ַ������ͺ��� 

void Usart_PutString(unsigned char  *pcString)
{
	while (*pcString != '\0')
	{
		Usart_PutChar(*pcString);
		pcString++;
	}
}

void UART_ISR(void) interrupt 4
{
	unsigned char temp;
	if(RI)
	{
		temp = SBUF;
		if(temp != ' ')
		{
			Enter_flag = 0;
			Rx_data[Rx_bit]=temp;
			Rx_bit++;
			Rx_counter++;

			if((Rx_bit==Rx_buffer_length)||(Rx_counter==Rx_buffer_length))
			{
				Rx_bit = 0;
			    Rx_counter = 0;	
			}
			if(temp == '\n')
			{
				Enter_flag = 1;
			}
		}
	}
}

//------------------------�������������� 

void Clear_Rxbuffer(unsigned char length)
{
	unsigned char Bit;
	for(Bit=0;Bit<length;Bit++)
	{
	    Rx_data[Bit]=0X00;
	}
	Rx_bit=0;
	Rx_counter=0;
}


void Clear_CurrentBuffer(unsigned char Bit,unsigned char length)
{
	unsigned char i=0;
	for(i;i<length;i++)
	{
		Rx_data[Bit]=0;
	}
}
