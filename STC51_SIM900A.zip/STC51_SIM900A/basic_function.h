#ifndef _BASIC_FUNCTION_H
#define _BASIC_FUNCTION_H

#define Rx_buffer_length    128

bit Enter_flag=0;

extern void Delay_us(unsigned int);
extern void Usart_Init(void);
extern void Usart_PutChar(unsigned char cTxData);
extern void Delay_ms(unsigned int);
extern void Usart_PutString(unsigned char  *pcString);
extern void UART_ISR(void);
extern void Clear_Rxbuffer(unsigned char length);
extern void Clear_CurrentBuffer(unsigned char Bit,unsigned char length);

extern unsigned char Rx_bit=0,Rx_counter=0;               	 //��־λ��λ������
extern unsigned char Rx_data[Rx_buffer_length]={0};         //���ջ�������

#endif