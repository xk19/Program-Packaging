#ifndef _DS18B20_H
#define _DS18B20_H

extern void TempDelay (unsigned char idata us);
extern void Init18b20 (void);
extern void WriteByte (unsigned char idata wr);  //���ֽ�д��
extern void read_bytes (unsigned char idata j);
extern unsigned char CRC (unsigned char j);
extern void GemTemp (void);
extern void Config18b20 (void);
extern void ReadID (void);
extern void TemperatuerResult(void);
extern bit ds18b20Flag;
extern unsigned int  idata Temperature;

#endif
