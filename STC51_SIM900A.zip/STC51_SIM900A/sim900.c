#include <sim900.h>
#include <reg52.h>

bit OK_flag=0;
bit SMS_Finish_flag=0; 
bit Ready_flag=0;  
bit Response_receive_SMS_flag=0;
bit RDY_flag=0;
bit CFUN_flag=0; 
bit AT_CREG_flag=0;
bit Enter_flag=0;

unsigned char Current_bit=0;
unsigned int  status_count=0;
unsigned char Rx_data[Rx_buffer_length];         //���ջ�������
unsigned char Rx_bit=0;
unsigned char Rx_counter=0;               	 //��־λ��λ������
unsigned char Rx_data[Rx_buffer_length]={0};         //���ջ�������

void UART_ISR(void) interrupt 4   //�жϷ�����
{
	unsigned char temp;
	P0=~P0;
	if(RI)
	{
		temp = SBUF;
		if(temp != ' ')
		{
			Enter_flag = 0;
			Rx_data[Rx_bit]=temp;
			Rx_bit++;
			Rx_counter++;

			if((Rx_bit==Rx_buffer_length)||(Rx_counter==Rx_buffer_length))
			{
				Rx_bit = 0;
			    Rx_counter = 0;	
			}
			if(temp == '\n')
			{
				Enter_flag = 1;
			}
		}
		RI = 0;
	}
}
//----------------------�ַ������ͺ��� 
void Usart_PutString(unsigned char  *pcString)
{
	while (*pcString != '\0')
	{
		Usart_PutChar(*pcString);
		pcString++;
	}
}	

void Usart_PutChar(unsigned char cTxData) 
{
	SBUF = cTxData;
	while(!TI);
		TI = 0;
}

void Usart_Init(void)
{
		SCON  = 0x50;		        // SCON: ģʽ 1, 8-bit UART, ʹ�ܽ���  
    TMOD |= 0x20;               // TMOD: timer 1, mode 2, 8-bit ��װ
    TH1   = 0xFD;               // TH1:  ��װֵ 9600 ������ ���� 11.0592MHz  
		TL1   = 0xfd;
	
    TR1   = 1;                  // TR1:  timer 1 ��                         
    EA    = 1;                  //�����ж�
    ES    = 1;     																
} 

//�������������� 
void Clear_Rxbuffer(unsigned char length) 
{
	unsigned char Bit;
	for(Bit=0;Bit<length;Bit++)
	{
	    Rx_data[Bit]=48;
	}
	Rx_bit=0;
	Rx_counter=0;
}

void Response_OK(void)     //�ظ�����
{
	unsigned char i=0;
	while(i<=MAXNUM_GSM)
    {
    	if(Rx_data[i]  =='O'&&Rx_data[i+1]=='K')
		{
			OK_flag=1;
		    Clear_Rxbuffer(Rx_buffer_length);        //���Rxbuffer
		    return ;
        } 
        i++;
    } 
	OK_flag=0;	 
}

void Response_Ready(void)   
{
	unsigned char  i=0;
    while(i<=MAXNUM_GSM)
    {
    	if(Rx_data[i]=='>')
        {
		  Ready_flag=1;     
		  Clear_Rxbuffer(Rx_buffer_length);        //���Rxbuffer       
		  return ;
        } 
        i++;
    }  
	Ready_flag=0;   
}

void Response_SMS_Finish(void)   
{
	unsigned char i=0;
    while(i <= MAXNUM_GSM)
    {
    	if(Rx_data[i]  =='+'
		&&Rx_data[i+1]=='C'
		&&Rx_data[i+2]=='M'
		&&Rx_data[i+3]=='G'
		&&Rx_data[i+4]=='S'
		&&Rx_data[i+5]==':')
        {
			SMS_Finish_flag=1;  
		    Clear_Rxbuffer(Rx_buffer_length);        //���Rxbuffer   
		    return ;	 
        } 
        i++;
    } 
	SMS_Finish_flag=0; 
}

unsigned char Response_receive_SMS(void)   //����Ƿ��յ�����
{
	unsigned char i=0;
    while(i<=MAXNUM_GSM)
    {
    	if(Rx_data[i]  =='+'
		&&Rx_data[i+1]=='C'
		&&Rx_data[i+2]=='M'
		&&Rx_data[i+3]=='T'
		&&Rx_data[i+4]=='I'
		&&Rx_data[i+5]==':')
		//Rx_data[i+7]=='"'
		//Rx_data[i+8]=='S'
		//Rx_data[i+9]=='M'
		//Rx_data[i+10]=='"'
		//Rx_data[i+11]==','
        { 
		   Response_receive_SMS_flag = 1; 
		   return i+11;	
        } 
    i++;
    }
//	Response_receive_SMS_flag = 0;
	return 0;
}   



void send_english_sms(void)	    
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8617697227056\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("WELCOME!The defence of the house is opened.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_help_sms(void)	   
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8617697227056\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("Send o to system to open the defence of the house!Send c to system to close the defence.Send t to system to show the temperature.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_curtain_open(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("The curtain has been opend.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_curtain_close(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("The curtain has been closed.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_sms_smog(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("WARNNING! Your family may be on fire.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_sms_infrared(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("WARNNING! Someone broke into your house.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_sms_water(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("WARNNING! Your house is flooded.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_sms_button(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8613659476545\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("You close the LED of wateralarm.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}
void send_english_sms_openDefence(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8617697227056\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("You have OPENED the defence of house.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}	  
void send_english_sms_closeDefence(void)
{
     Usart_PutString("AT\r");
	 Delay_ms(100);   //�ȷ����ź���ʱ   
     Response_OK();                                 //���� OK
	 Delay_ms(100);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGF=1\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ     
	 Response_OK();                                 //���� OK
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
              
	 Usart_PutString("AT+CSCS=\"GSM\"\r");
	 Delay_ms(100);  //�ȷ����ź���ʱ    
	 Response_OK();                                 //���� 0K
     Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	
     Usart_PutString("AT+CMGS=\"+8617697227056\"\r ");        // AT+CMGS

	 Delay_ms(100);      //�ȷ����ź���ʱ
	 Response_Ready();                              // ���� >
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 
     Usart_PutString("You have CLOSED the house of defence.\x01a");   
	 Delay_ms(500); Delay_ms(500); Delay_ms(500); //�ȷ����ź���ʱ    
	 Response_SMS_Finish(); 
	 Delay_ms(200);
	 Clear_Rxbuffer(Rx_buffer_length);        //��Rxbuffer
	 Delay_ms(10);
}	  	   