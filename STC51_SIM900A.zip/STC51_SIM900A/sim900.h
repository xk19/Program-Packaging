#ifndef _SIM900_H
#define _SIM900_H


#define MAXNUM_GSM     80        //�����80

#define Rx_buffer_length    80  //�������ݳ���80



extern void Usart_PutChar(unsigned char cTxData);
extern void Delay_ms(unsigned int);
extern void Usart_PutString(unsigned char  *pcString);
extern void Clear_Rxbuffer(unsigned char length);
extern void Clear_CurrentBuffer(unsigned char Bit,unsigned char length);

extern unsigned char Rx_bit;
extern unsigned char Rx_counter;               	 //��־λ��λ������
extern unsigned char Rx_data[Rx_buffer_length];         //���ջ�������

extern bit OK_flag;
extern bit SMS_Finish_flag; 
extern bit Ready_flag;  
extern bit Response_receive_SMS_flag;
extern bit RDY_flag;
extern bit CFUN_flag; 
extern bit AT_CREG_flag;

extern void Response_OK(void);
extern void Response_Ready(void);
extern void Response_SMS_Finish(void);
extern unsigned char Response_receive_SMS(void);
extern void Response_AT_CREG(void);
extern void send_english_sms(void);                      		 //����Ӣ�Ķ���
extern void send_english_sms_parameter(unsigned char *unmber,unsigned char *Data); 
extern void send_english_curtain_close(void);
extern void send_english_curtain_open(void);
extern void send_english_sms_smog(void);
extern void send_english_sms_infrared(void);
extern void send_english_sms_water(void);
extern void send_english_sms_button(void);
extern void send_english_sms_closeDefence(void);
extern void send_english_sms_openDefence(void);
extern void send_help_sms(void);
extern void UART_ISR(void);   //�жϷ�����
extern void Usart_PutString(unsigned char  *pcString);
extern void Usart_PutChar(unsigned char cTxData) ;
extern void Usart_Init(void);
extern void Clear_Rxbuffer(unsigned char length) ;

#endif