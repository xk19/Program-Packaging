


#ifndef     _stepper_motor_H
#define     _stepper_motor_H

#define uchar unsigned char 
#define uint unsigned int

void delay_ms_motor(uchar ms);
void motor_forward(uint n);
void motor_backward(uint n);


#endif
