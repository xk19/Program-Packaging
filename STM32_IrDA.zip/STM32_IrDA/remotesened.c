#include "remotesend.h"
#include "delay.h"
#include "usart.h"

//��ʼ�������ز��ź�
//ʹ��TIM3�����ز� 
void pwm_init(unsigned short psc,unsigned short arr)
{
	TIM_OCInitTypeDef TIM_OCInitStruct;
	GPIO_InitTypeDef GPIO_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler = psc;
	TIM_DeInit(TIM3);
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
	TIM_OCInitStruct.TIM_OCPolarity  = TIM_OCPolarity_Low;
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStruct.TIM_Pulse = 0;
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OC2Init(TIM3,&TIM_OCInitStruct);
	TIM_ARRPreloadConfig(TIM3,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
}
//��ʼ��C8��Сϵͳ�İ���LED�����õİ��� 
void key_led_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//��ʼ��C��ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//��ʼ��A��ʱ��
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_15;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	LED = 0;
} 
//��ʼ��TIM2�����ڶ�ʱ�ж��Ա���������ʹ�� 
void pit_init(unsigned short psc,unsigned short arr)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler = psc;
	TIM_DeInit(TIM2);
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM2,ENABLE);
	NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStruct);
} 
//����ɨ�躯��
unsigned char key_scan()
{
	if(!KEY1)	
	{
		delay_ms(10);
		if(!KEY1)
		{
			while(!KEY1);
			return 1;
		}
	}
	if(!KEY2)
	{
		delay_ms(10);
		if(!KEY2)
		{
			while(!KEY2);
			return 2;
		}
	}
	if(!KEY3)
	{
		delay_ms(10);
		if(!KEY3)
		{
			while(!KEY3);
			return 3;
		}
	}
	if(!KEY4)
	{
		delay_ms(10);
		if(!KEY4)
		{
			while(!KEY4);
			return 4;
		}
	}
	if(!KEY5)
	{
		delay_ms(10);
		if(!KEY5)
		{
			while(!KEY5);
			return 5;
		}
	}
	if(!KEY6)
	{
		delay_ms(10);
		if(!KEY6)
		{
			while(!KEY6);
			return 6;
		}
	}
	if(!KEY7)
	{
		delay_ms(10);
		if(!KEY7)
		{
			while(!KEY7);
			return 7;
		}
	}
	if(!KEY8)
	{
		delay_ms(10);
		if(!KEY8)
		{
			while(!KEY8);
			return 8;
		}
	}
	return 0;
} 
void sendbyte(unsigned char dat)
{
	PWM1;
	delay_ms(20*dat);
	PWM0;
	USART_SendData(USART1,dat+'0');  
}

