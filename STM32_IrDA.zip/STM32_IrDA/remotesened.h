#ifndef __REMOTESEND_H
#define __REMOTESEND_H 
#include "sys.h"   

#define PWM0 TIM_SetCompare2(TIM3,0)
#define PWM1 TIM_SetCompare2(TIM3,300)

#define LED PCout(13)
#define KEY1 PAin(6)
#define KEY2 PAin(5)
#define KEY3 PAin(4)
#define KEY4 PAin(3)
#define KEY5 PAin(2)
#define KEY6 PAin(1)
#define KEY7 PAin(0)
#define KEY8 PCin(15)

void pwm_init(u16 psc,u16 arr);

void pit_init(u16 psc,u16 arr);

void key_led_init(void);

unsigned char key_scan(); 

void sendbyte(unsigned char dat);

#endif














