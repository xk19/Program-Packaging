#ifndef _OLED_H
#define _OLED_H

#include "stc12c5a60s2.h"
#include "intrins.h" 

#define byte  unsigned char
#define word  unsigned int
#define dword unsigned long  
		
void LCD_Init(void);
void LCD_CLS(void);
void LCD_P6x8Str(unsigned char x,unsigned char y,unsigned char ch[]);	  
void LCD_Fill(unsigned char dat);
	
#endif

