#ifndef _ADC_H_
#define _ADC_H_


void adc_init();

void adc_start();

unsigned int adc_8bit_conv();

unsigned int adc_10bit_conv();

#endif