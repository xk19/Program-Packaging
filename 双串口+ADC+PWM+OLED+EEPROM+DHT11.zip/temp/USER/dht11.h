#ifndef _DHT11_H_
#define _DHT11_H_



void receive(unsigned char dhtd[4]);



#endif

