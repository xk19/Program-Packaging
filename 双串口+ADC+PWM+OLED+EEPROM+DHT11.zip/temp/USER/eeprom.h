#ifndef _EEPROM_H_
#define _EEPROM_H_

void disableeeprom(void);

unsigned char eeprom_read_n(unsigned int EE_address);

void eeprom_SectorErase(unsigned int EE_address);
	
void eeprom_write_n(unsigned int EE_address,unsigned char DataAddress);

#endif