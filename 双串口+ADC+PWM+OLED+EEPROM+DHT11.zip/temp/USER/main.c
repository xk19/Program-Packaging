#include "stc12c5a60s2.h"
#include "intrins.h"
#include "stdio.h"
#include "pwm.h"
#include "uart.h"
#include "adc.h"
#include "eeprom.h"
#include "OLED.h"
#include "dht11.h"
char send_buff[10];
char send_dht11[14];
unsigned int adc = 0;
unsigned char pwm = 000;
unsigned char dht[4] = {0x00,0x00,0x00,0x00};
int main()
{
	LCD_Init();
	LCD_CLS();
	pwm = eeprom_read_n(0x0032);
	uart1_init();//����2��P13P12
	pwm_init();//PWM��P42
	pwm_change(pwm);
	adc_init();
	while(1)
	{
		receive(dht);
		adc_start();
		adc = adc_10bit_conv();
		pwm_change(pwm);
		sprintf(send_buff,"adc:%4d",(int)adc);
		sprintf(send_dht11,"%d.%d+%d.%d",(int)dht[0],(int)dht[1],(int)dht[2],(int)dht[3]);
		LCD_P6x8Str(0,0,send_buff);
		uart1_send_str(send_dht11);
		delay(200);
		delay(200);
		delay(200);
		delay(200);
		delay(200);
		delay(200);
	}
}
void uart1() interrupt 4
{
	if(SCON&0x01)//�����ж�
	{
		SCON &= 0xFE;//������ܱ�־λ
		//�û�����
		pwm = SBUF;
		eeprom_SectorErase(0X0032);
		eeprom_write_n(0x0032,pwm);
	}
	if(SCON&0x02)//�����ж���
	{
		SCON &= 0xFD;//����жϱ�־λ
	}
}



