#ifndef _PWM_H_ 
#define _PWM_H_




void pwm_init();

void steer_init(); 

void pwm_change(unsigned char pwm1_pwm);

#endif















