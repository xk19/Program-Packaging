#ifndef _UART_H_
#define _UART_H_

#include "stc12c5a60s2.h"
#include "intrins.h"
#include "stdio.h"

void uart_init();
void uart1_init();
void uart2_init();

void delay(unsigned int delay_ms);
void uart1_send_str(char send1_buffer[]);
void uart2_send_str(char send2_buffer[]);
void uart1_send_char(char send1_char);
void uart2_send_char(char send2_char);




#endif